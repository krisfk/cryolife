!function($) {
    "use strict";

    setTimeout(function() {
    	window.itemIndex();
    }, 1000);

}(window.jQuery);
